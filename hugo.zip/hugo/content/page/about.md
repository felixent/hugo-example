---
title: About me
subtitle: Why you'd want to hang out with me
comments: false
---

My name is The mosquito. I have the following qualities:

- I rock a great techs;
- I'm extremely loyal to my professionalism.
- I like hunting

Slogan-Life without learning is death.

### my history

To be honest, I'm having some trouble remembering right now, so why don't you
just watch [my movie](https://en.wikipedia.org/wiki/mosquito) and it
will answer **all** your questions.
